<?php

  $data = json_decode(file_get_contents("php://input"));
    $index = $data->id;


 $servername = "localhost";
$username = "amartech_think";
$password = "cIDIWR1tz[ie";
$dbname = "amartech_thinkinc";

mysql_connect($servername,$username,$password);
mysql_select_db($dbname);
  mysql_query("DELETE FROM my_test2 WHERE id = '".$index."'");

?>