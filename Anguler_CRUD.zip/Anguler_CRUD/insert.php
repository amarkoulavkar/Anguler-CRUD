<?php

$data = json_decode(file_get_contents("php://input"));

$name = $data->name;

$address = $data->username;

$phone = $data->email;

 $servername = "localhost";
$username = "amartech_think";
$password = "cIDIWR1tz[ie";
$dbname = "amartech_thinkinc";

mysql_connect($servername,$username,$password);
mysql_select_db($dbname);
  mysql_query("INSERT INTO `my_test2`(`name`, `username`, `email`) VALUES ('".$name."','".$address."','".$phone."')");
?>