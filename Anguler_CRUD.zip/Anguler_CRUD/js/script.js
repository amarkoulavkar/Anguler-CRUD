var app = angular.module('myapp',[]);


app.controller('myCtrl',['$scope','myService',function($scope,myService){

	$scope.datas=function(){
	$scope.users = myService.getUsers();
	}
	
}]); 
 
 

app.directive('contenteditable', function() {
    return {
        require: 'ngModel',
        link: function(scope, elm, attrs, ctrl) {
            // view -> model
            elm.bind('blur', function() {
                scope.$apply(function() {
                    ctrl.$setViewValue(elm.html());
                });
            });

            // model -> view
            ctrl.render = function(value) {
                elm.html(value);
            };

            // load init value from DOM
            ctrl.$setViewValue(elm.html());

            elm.bind('keydown', function(event) {
                console.log("keydown " + event.which);
                var esc = event.which == 27,
                    el = event.target;

                if (esc) {
                        console.log("esc");
                        ctrl.$setViewValue(elm.html());
                        el.blur();
                        event.preventDefault();                        
                    }
                    
            });
            
        }
    };
}); 
 
 
app.controller('customersCtrl', function($scope, $http,$interval) {
  $http.get("index.php").then(function (response) {
                $scope.myData = response.data;
            });
  
    $scope.getMessage = function() {
        setTimeout(function() {
            $http.get("index.php").then(function (response) {
                $scope.myData = response.data;
            });
            console.log('message:'+$scope.myData);
        }, 1000);
    }      
  
  
		// function to submit the form after all validation has occurred			
		$scope.submitForm = function() {

			// check to make sure the form is completely valid
			if ($scope.userForm.$valid) {
				alert('our form is amazing');
			}

		};
  
  
  
  $scope.insertData=function(){
      $scope.getMessage();
      $http.post("insert.php",{'name':$scope.user.name,'username':$scope.user.username,'email':$scope.user.email})
	  .success(function(data,status,headers,config){
	      console.log("data inserted successfully");
	  }).error(function() {
          console.log('oh well');
      });
  }
  
  

  
  
   $scope.deleteData = function(index) {
	    $scope.loading = true;
       $scope.getMessage();
       console.log(index);
       $http.post('delete.php', {
          'id': index
       })
    .success(function() {
		  $scope.loading = false;
       console.log("data deleted successfully");
    })
    .error(function() {
      console.log('oh well');
    });
  }
    
     
}); 





 