<?php

  $data = json_decode(file_get_contents("php://input"));
   $index = $data->id;
   $name = $data->name;
  $address = $data->address;
  $phone = $data->phone;
  
 $servername = "localhost";
$username = "amartech_think";
$password = "cIDIWR1tz[ie";
$dbname = "amartech_thinkinc";

mysql_connect($servername,$username,$password);
mysql_select_db($dbname);
  mysql_query("UPDATE MyGuests SET name='".$name."','".$address."','".$phone."' WHERE id='".$index."'");

?>