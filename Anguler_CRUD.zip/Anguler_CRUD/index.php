<?php
 $servername = "localhost";
$username = "amartech_think";
$password = "cIDIWR1tz[ie";
$dbname = "amartech_thinkinc";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}else{
 
} 

$sql = "SELECT * FROM my_test2";
$result = $conn->query($sql);
//create an array
    $emparray = array();
    while($row =mysqli_fetch_assoc($result))
    {
        $emparray[] = $row;
    }

echo json_encode($emparray);
?>  
